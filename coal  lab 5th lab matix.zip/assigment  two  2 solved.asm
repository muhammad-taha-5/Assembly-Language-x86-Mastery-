.stack 0x100
.model small
.data
 a db 0,0,0,0,0xff,0xff,0xff,0xff 
 b db 0x12, 0x34, 0x56,0x78 
 c db  0,0,0,0,0,0,0,0
  n db 32 
.code 
main proc  
    mov ax,@data
    mov ds,ax 
   mov bx ,offset A+7
   mov si ,offset b+3
   mov di, offset c+7  
 
    str:
   
    mov al,[si]
    and al,1
    cmp al,1 
     jE addit: 
              
 return:  ; here the this returns 
        
     
       clc  ; this means  that we cancel the  carry!
         RCL [bx],1
         RCL [bx-1],1
         RCL [bx-2],1
         RCL [bx-3],1           
         RCL [bx-4],1       
         RCL [bx-5],1         
         RCL [bx-6],1
         RCL [bx-7],1         
        clc  ; this means that SHFTING OF THE  Q TO THE right   
         RCR [SI-3],1
         RCR [SI-2],1     
         RCR [SI-1],1     
         RCR [SI-0],1     
       
 
      dec n
      cmp n,0
      jNE str : 
      
main endp
   .exit 
     addit:
  mov ah,[bx]
  add ah,[di]
   
  mov ah,[bx-1]
  adc [di-1],ah
  
  mov ah,[bx-2]
  adc [di-2],ah
   
  mov ah,[bx-3]
  adc [di-3],ah
  
  mov ah,[bx-4]
  adc [di-4],ah
     
  mov ah,[bx-5]
  adc [di-5],ah 
  
  mov ah,[bx-6]
  adc [di-6],ah
     
  mov ah,[bx-7]
  adc [di-7],ah 
  
    jmp return:
    
    
    
    