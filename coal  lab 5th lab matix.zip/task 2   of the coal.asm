;Task-1
;Write a program that declares and initializes an array with 10 elements, then uses a loop to find the sum of those elements and stores the result in a variable named "SUM".
 
 .stack 0x100
 .model small  
 .data
  
  arr1 dw 9 dup (3) 
    
  arr2 dw 9 dup (4)  
      
  arr3 dw 9 (?)
     
      
 .code 
  main  proc 
    mov ax, @data
    mov ds, ax
        
       mov si, 0
       mov  cx ,20
str: 
       mov  ax,[arr1+si] 
       mov  bx,[arr2+si] 
       add ax,bx   
       mov [arr3+si],ax
       inc si 
           
             
           
loop str: 
        
        
    
        hlt
    main endp  
        .exit 
  
  

