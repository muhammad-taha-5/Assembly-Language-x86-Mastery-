;Task-1
;Write a program that declares and initializes an array with 10 elements, then uses a loop to find the sum of those elements and stores the result in a variable named "SUM".
 
 .stack 0x100
 .model small  
 .data
   sum db 0
  arr  db 10 dup (3)  
 
 .code 
  main  proc 
    mov ax, @data
    mov ds, ax 
       
     mov bx, offset arr
       mov si, 0
             mov  cx ,10 
         str:
            
       add   dl,[bx+si]     
              
           inc si  
               
         loop str: 
     
             mov sum,dl
         
           
         
         
    
        hlt
    main endp  
        .exit 
  
  

