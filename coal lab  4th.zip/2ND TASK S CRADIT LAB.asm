 .stack 0x100 
 .model small 
 .data 
 .code 
 
 
 
 proc 
mov ax, 0xabcd     
mov ds,ax

           
 mov ds:[1400],0x210A             
 mov ds:[1402],0x0505 
      
    mov ds:[1404],0xB0B0       
    mov ds:[1406],0x2001
    
     mov ds:[1408],0x1000
         
       
        mov ax,  ds:[1400]
        mov  bx ,ds:[1402] 
        mov  Cx ,ds:[1404]
                   ; added 
        add  ax,bx
        add  ax, cx 
        
                        ;reading the data  
        mov  bx ,ds:[1406] 
        mov  Cx ,ds:[1408]
           
          sub ax, bx
          sub ax, cx  
               ; now here the data is storeed in the ax  register  ax= A6BE    
           
                                                                       ;ax= A6BE  ANSWER  
           
   endp 
         .exit 
          