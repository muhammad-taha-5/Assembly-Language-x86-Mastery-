 .stack 0x100
 .model small
 .data
 .code
      
 mian proc
            
              
    mov ax,0xabcd
    mov ds,ax
              ;CX = AX + CX - BL + DX + DH
          mov AX, 0x1200
          mov BX, 0x45F3   
          mov CX, 0x0A21  
          mov DX, 0x00B5  
               
                    
             add  cx,ax
             add  cx,dx 
             mov  bh,0
             sub  cx,bx
             add  cl,dh       
                    
                    
                    ;this the ans in the  CX = 1BE3h     
                    
                    
              hlt       
                    
                    
                    
                    
   mian endp 
       .exit 
    
    
    
    