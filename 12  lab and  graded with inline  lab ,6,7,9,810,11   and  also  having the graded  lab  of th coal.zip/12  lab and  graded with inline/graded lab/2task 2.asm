.stack 0x100
.model samll|
.data
str db 25,0,25 dup('$') 
 row db 8
 col db 15
  newline db 0xD,0xA,'$'   
.code
main proc 
mov ax ,@data 
mov ds, ax 

 
  mov ah,02h   ;; set      
  mov bh,02h
  mov dl,col 
  mov dh,row     
  int 21h 
  
  mov si,0  
   
 mov ah,0Ah
 lea dx,str   
 int 21h
        
 mov cl,[str]     
   
  
   l1:   
   
       
                 ; newline  wraping line 
  mov ah,9h
  lea dx,newline
  int 21h          
    
    
           ; string   
 mov ah,9h 
 lea dx,[str+si]   
 int 21h
        
 inc si 
 dec cl    
 cmp cl,'$'    
 je l1: 
 
 display 
 
   
    
endp main 
.exit 
     
