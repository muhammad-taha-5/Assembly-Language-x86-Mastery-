.stack 0x100
.model samll|
.data
  w1 dw 9475h
  w2 dw 8743h 

.code
main proc 
mov ax ,@data 
mov ds, ax 

 mov ax,0 
 mov es,ax 
 mov word ptr es:[101*4+0],apna
 mov word ptr es:[101*4+2],cs
 
 mov ah,1 ;this  is the call for  added
 int 65h  
 
 mov ah,2  ;this  is the call for multiply
 int 65h
  
    
 mov ah,3  ;this  is the call for divide     
 int 65h
          
    
    
    
    
    
    
    
    
endp main 
.exit 
     
apna proc   
    
  cmp ah,2   
  je multi:
        
  cmp ah,1   
  je  addd:
  
  cmp ah,3   
  je divid:
     
     
  addd:    
   mov si,w1    
   mov di,w1    
       
  mov ax,si
  add ax,di
   mov [bx],ax 
        
 iret    
 multi:
      
   mov si,w1    
   mov di,w1    
       
  mov ax,si
  mov bx,di
   
  mul  bx 
   mov [bx],ax 
            
   mov [bx+2],dx   
      
      
      
   
iret 
divid:  

   mov si,w1    
   mov di,w1    
       
   mov ax,si
   mov bx,di
   
   div  bx      
   
   mov [bx],ax    
   mov [bx+2],dx   
      




 iret 
endp apna

     
     