#include<iostream> 
using namespace std; 
int main(void){
	int array1[3][4] = { {1,2,3,1},{4,5,6,1},{7,8,9,1} };
	int index = 0;
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 4; j++)
		{
			index = (i * 4 + j) * sizeof(int);
			_asm
			{
			mov eax, index
			add dword ptr[array1 + eax],1
			}
			cout << "(" << i << "," << j << ")" << "->" << array1[i][j] << endl;
		}

}
