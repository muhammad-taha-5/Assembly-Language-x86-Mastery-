#include <iostream>
using namespace std;

int main() {
    int arr[5] = {
        0x12345678,
        0x89ABCDEF,
        0x0F1E2D3C,
        0xA1B2C3D4,
        0x55667788
    };

    cout << "Before:\n";
    for (int i = 0; i < 5; i++)
        cout << hex << arr[i] << endl;
    for (int i = 0; i < 5; i++)
    {
        __asm {
            mov eax, arr[i]
            mov ebx, eax    // store and perserve   bx smae  0x  0x12345678 
            and eax, 0x00ffff00  // mask  
            
            mov ecx,ebx 
            and  ecx,0x000000ff
            shl ecx, 24
            or eax, ecx

            mov ecx ,ebx
            and ecx,0xff000000
            shr ecx,24 
            or eax, ecx

            mov  ecx,ebx
            and  ecx, 0x00ffff00
            or eax,ecx 
            mov arr[i],eax


        }
    }

    cout << "Before:\n";
    for (int i = 0; i < 5; i++)
        cout << hex << arr[i] << endl;

    return 0;
}
